/*******************************************
Assignment 1B
CSci 5103 Operating Systems Fall 2012
Author: Matthew Le
Student Id: 3975089
x500: lexxx320
********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <signal.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/types.h>



